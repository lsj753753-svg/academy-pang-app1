// 위치: android/app/src/main/java/com/bubblepang/game/MainActivity.java
package com.bubblepang.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    // Capacitor이 자동으로 WebView에 index.html을 로드합니다.
    // 추가 플러그인이 필요하면 이 클래스에서 등록하세요.
}
