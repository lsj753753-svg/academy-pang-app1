@echo off
REM ============================================================
REM 버블 팡 APK 빌드 스크립트 (Windows용)
REM ============================================================

echo 🫧 버블 팡 APK 빌드 시작
echo ================================

REM Node.js 확인
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [오류] Node.js가 설치되지 않았습니다.
    echo       https://nodejs.org 에서 설치 후 다시 실행하세요.
    pause
    exit /b 1
)

echo [확인] Node.js 버전:
node -v

REM 패키지 설치
echo.
echo [1/5] npm 패키지 설치 중...
call npm install

REM Android 플랫폼 추가
echo.
echo [2/5] Android 플랫폼 추가 중...
call npx cap add android

REM 파일 동기화
echo.
echo [3/5] 파일 동기화 중...
call npx cap sync android

REM 리소스 파일 복사
echo.
echo [4/5] 리소스 파일 적용 중...
if not exist "android\app\src\main\res\values" mkdir "android\app\src\main\res\values"
copy "android-config\strings.xml" "android\app\src\main\res\values\strings.xml" /y
copy "android-config\styles.xml" "android\app\src\main\res\values\styles.xml" /y

REM APK 빌드
echo.
echo [5/5] APK 빌드 중...
cd android
call gradlew.bat assembleDebug

if %errorlevel% equ 0 (
    echo.
    echo ✅ APK 빌드 성공!
    echo 📱 파일 위치: android\app\build\outputs\apk\debug\app-debug.apk
) else (
    echo.
    echo ❌ 빌드 실패. 오류를 확인하거나 Android Studio를 사용하세요.
    echo    명령어: npx cap open android
)

pause
