#!/usr/bin/env python3
"""
아이콘 생성 스크립트
pip install pillow 설치 후 실행: python3 generate_icons.py
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_bubble_icon(size, output_path):
    """버블 팡 앱 아이콘 생성"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # 배경 원 (하늘색)
    margin = int(size * 0.04)
    draw.ellipse([margin, margin, size - margin, size - margin],
                 fill='#4fc3f7')

    # 큰 버블 (분홍)
    b1 = int(size * 0.15)
    b1e = int(size * 0.65)
    draw.ellipse([b1, b1, b1e, b1e], fill='#ff4081')

    # 버블 광택
    draw.ellipse([int(size*0.2), int(size*0.18), int(size*0.38), int(size*0.33)],
                 fill='rgba(255,255,255,120)')

    # 작은 버블들
    draw.ellipse([int(size*0.58), int(size*0.22), int(size*0.82), int(size*0.48)],
                 fill='#7c4dff')
    draw.ellipse([int(size*0.55), int(size*0.58), int(size*0.75), int(size*0.78)],
                 fill='#00c853')

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)
    img.save(output_path, 'PNG')
    print(f"✅ 아이콘 생성: {output_path} ({size}x{size})")

# Android 아이콘 사이즈
icon_sizes = {
    'icons/mipmap-mdpi/ic_launcher.png': 48,
    'icons/mipmap-hdpi/ic_launcher.png': 72,
    'icons/mipmap-xhdpi/ic_launcher.png': 96,
    'icons/mipmap-xxhdpi/ic_launcher.png': 144,
    'icons/mipmap-xxxhdpi/ic_launcher.png': 192,
    'icons/mipmap-mdpi/ic_launcher_round.png': 48,
    'icons/mipmap-hdpi/ic_launcher_round.png': 72,
    'icons/mipmap-xhdpi/ic_launcher_round.png': 96,
    'icons/mipmap-xxhdpi/ic_launcher_round.png': 144,
    'icons/mipmap-xxxhdpi/ic_launcher_round.png': 192,
    'icons/playstore-icon.png': 512,
}

print("🫧 버블 팡 아이콘 생성 중...")
for path, size in icon_sizes.items():
    os.makedirs(os.path.dirname(path), exist_ok=True)
    create_bubble_icon(size, path)

print("\n✨ 모든 아이콘 생성 완료!")
print("📁 icons/ 폴더의 각 mipmap 폴더를 android/app/src/main/res/ 에 복사하세요.")
