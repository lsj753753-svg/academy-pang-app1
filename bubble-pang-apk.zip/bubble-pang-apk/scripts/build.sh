#!/bin/bash
# ============================================================
# 버블 팡 APK 빌드 자동화 스크립트
# 사전 준비: Node.js, Java JDK 17+, Android Studio 설치 필요
# ============================================================

echo "🫧 버블 팡 APK 빌드 시작"
echo "================================"

# 1. 환경 확인
echo "📋 환경 확인 중..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js가 설치되지 않았습니다."
    echo "   👉 https://nodejs.org 에서 설치하세요."
    exit 1
fi

if ! command -v java &> /dev/null; then
    echo "❌ Java JDK가 설치되지 않았습니다."
    echo "   👉 https://adoptium.net 에서 JDK 17을 설치하세요."
    exit 1
fi

echo "✅ Node.js: $(node -v)"
echo "✅ Java: $(java -version 2>&1 | head -1)"

# 2. 패키지 설치
echo ""
echo "📦 패키지 설치 중..."
npm install

# 3. Capacitor Android 플랫폼 추가
echo ""
echo "🤖 Android 플랫폼 추가 중..."
npx cap add android

# 4. 웹 파일 동기화
echo ""
echo "🔄 파일 동기화 중..."
npx cap sync android

# 5. 아이콘 복사
echo ""
echo "🎨 아이콘 복사 중..."
if [ -d "icons" ]; then
    for dpi in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
        src="icons/mipmap-${dpi}"
        dst="android/app/src/main/res/mipmap-${dpi}"
        if [ -d "$src" ]; then
            mkdir -p "$dst"
            cp "$src"/*.png "$dst/" 2>/dev/null || true
        fi
    done
    echo "✅ 아이콘 복사 완료"
else
    echo "⚠️  icons/ 폴더 없음. generate_icons.py 먼저 실행하세요."
fi

# 6. strings.xml 복사
echo ""
echo "📝 리소스 파일 적용 중..."
mkdir -p android/app/src/main/res/values
cp android-config/strings.xml android/app/src/main/res/values/strings.xml
cp android-config/styles.xml android/app/src/main/res/values/styles.xml
echo "✅ 리소스 파일 적용 완료"

# 7. APK 빌드
echo ""
echo "🔨 APK 빌드 중..."
cd android

if [ "$(uname)" == "Darwin" ] || [ "$(uname)" == "Linux" ]; then
    ./gradlew assembleDebug
else
    # Windows
    cmd //c gradlew.bat assembleDebug
fi

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 APK 빌드 성공!"
    APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
    if [ -f "$APK_PATH" ]; then
        echo "📱 APK 파일 위치: android/$APK_PATH"
        SIZE=$(du -sh "$APK_PATH" | cut -f1)
        echo "📦 파일 크기: $SIZE"
    fi
else
    echo ""
    echo "❌ 빌드 실패. 위의 오류 메시지를 확인하세요."
    echo "💡 Android Studio에서 직접 빌드를 시도해보세요: npx cap open android"
fi
